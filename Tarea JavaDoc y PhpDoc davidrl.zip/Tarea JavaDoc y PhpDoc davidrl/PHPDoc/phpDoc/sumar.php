<?php
    /**
    * Clase que representa una calculadora.
    */
class Calculadora {

    /**
     * Calcula la suma de dos números.
     *
     * @param int $a Primer número.
     * @param int $b Segundo número.
     * @return int La suma de los dos números.
     */
    public function sumar($a, $b) {
        return $a + $b;
    }

    /**
     * Calcula la resta de dos números.
     *
     * @param int $a Primer número.
     * @param int $b Segundo número.
     * @return int La resta de los dos números.
     */
    public function restar($a,$b){
        return $a - $b;
    }

    /**
     * @var string Mensaje de bienvenida.
     */
    public $mensaje = "¡Bienvenido a la calculadora!";

    // Otros métodos y propiedades de la clase...
}

?>