Search.appendIndex(
    [
                {
            "fqsen": "\\Calculadora",
            "name": "Calculadora",
            "summary": "Clase\u0020que\u0020representa\u0020una\u0020calculadora.",
            "url": "classes/Calculadora.html"
        },                {
            "fqsen": "\\Calculadora\u003A\u003Asumar\u0028\u0029",
            "name": "sumar",
            "summary": "Calcula\u0020la\u0020suma\u0020de\u0020dos\u0020n\u00FAmeros.",
            "url": "classes/Calculadora.html#method_sumar"
        },                {
            "fqsen": "\\Calculadora\u003A\u003Arestar\u0028\u0029",
            "name": "restar",
            "summary": "Calcula\u0020la\u0020resta\u0020de\u0020dos\u0020n\u00FAmeros.",
            "url": "classes/Calculadora.html#method_restar"
        },                {
            "fqsen": "\\Calculadora\u003A\u003A\u0024mensaje",
            "name": "mensaje",
            "summary": "",
            "url": "classes/Calculadora.html#property_mensaje"
        },                {
            "fqsen": "\\",
            "name": "\\",
            "summary": "",
            "url": "namespaces/default.html"
        }            ]
);
